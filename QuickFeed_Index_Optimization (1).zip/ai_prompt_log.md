# Nhật ký phân tích với AI — QuickFeed

Yêu cầu thực tế: hoàn thành bài thực hành QuickFeed, gồm script xóa có chọn lọc ba index đã được đề bài chỉ định, báo cáo Read/Write và nhật ký phân tích. Nội dung dưới đây ghi các câu hỏi phân tích và kết luận trong phiên hỗ trợ này, không mô tả một lịch sử hội thoại nhiều lượt đã diễn ra.

## 1. Cardinality và độ chọn lọc

Câu hỏi phân tích: Cardinality là gì? Boolean có luôn là ứng cử viên vô dụng cho B-Tree không?

Kết luận: Cardinality là số giá trị khác nhau; `SHOW INDEX` cung cấp ước lượng, còn `COUNT(DISTINCT ...)` đối chiếu dữ liệu. Độ chọn lọc còn phụ thuộc tỷ lệ dòng khớp điều kiện. Khi `is_visible=1` khớp 99% dòng, index ít giúp loại bỏ dòng; lấy `SELECT *` qua index phụ còn cần truy cập clustered index. Optimizer có thể chọn quét bảng. Tuy nhiên, tìm 1% bài ẩn, dùng covering index hoặc index ghép có thể vẫn hiệu quả. Vì vậy không kết luận mọi Boolean index đều vô dụng.

Nguồn: https://dev.mysql.com/doc/refman/8.4/en/table-scan-avoidance.html

## 2. Data Pages, Index Pages và INSERT

Câu hỏi phân tích: Năm secondary index làm phát sinh công việc vật lý nào khi INSERT?

Kết luận: InnoDB lưu dữ liệu hàng trong clustered index; mỗi secondary index lưu khóa của nó kèm khóa chính để tìm hàng. Một INSERT cần duy trì clustered index và năm index phụ. Trang được sửa trong buffer pool; ghi log, page split và cơ chế flush/change buffering ảnh hưởng I/O. Không đồng nhất “sáu cây” với “sáu lần ghi vật lý ngay lập tức”, cũng không quy toàn bộ timeout chỉ cho index khi chưa đo lock, I/O và tài nguyên.

Nguồn: https://dev.mysql.com/doc/refman/8.0/en/innodb-index-types.html

## 3. Đo dung lượng và giải phóng ổ đĩa

Câu hỏi phân tích: Truy vấn nào đo Data/Index MB? DROP INDEX có trả ngay dung lượng cho hệ điều hành không?

Kết luận: Đọc `DATA_LENGTH`, `INDEX_LENGTH`, `DATA_FREE` từ `information_schema.TABLES`, lọc cả schema lẫn table và chia 1.048.576. Với InnoDB, DATA_LENGTH là không gian xấp xỉ cấp cho clustered index, INDEX_LENGTH cho index phụ. `ANALYZE TABLE` cập nhật thống kê; `information_schema_stats_expiry=0` tránh số liệu cache trên MySQL 8.0. Trang giải phóng sau DROP có thể được tablespace tái sử dụng, trong khi file .ibd không giảm kích thước. Rebuild/OPTIMIZE với file-per-table có thể trả không gian về OS nhưng cần dung lượng tạm và lịch bảo trì; không tự chạy khi disk đang đầy.

Nguồn:
- https://dev.mysql.com/doc/mysql-infoschema-excerpt/8.0/en/information-schema-tables-table.html
- https://dev.mysql.com/doc/refman/8.0/en/innodb-file-space.html

## 4. B-Tree tiền tố và FULLTEXT

Câu hỏi phân tích: `content(255)` có tìm được từ khóa bất kỳ trong văn bản? FULLTEXT có luôn tiết kiệm dung lượng hơn không?

Kết luận: B-Tree tiền tố có thể phục vụ điều kiện tiền tố như `LIKE 'abc%'` tùy kế hoạch truy vấn, nhưng thường không hỗ trợ `LIKE '%abc%'`. FULLTEXT phù hợp tìm theo từ bằng `MATCH ... AGAINST`, có stopword và giới hạn độ dài token, không tương đương tìm mọi chuỗi con. Nó cũng cần lưu chỉ mục, không bảo đảm nhỏ hơn B-Tree tiền tố. Bài này chỉ đề xuất, không tạo FULLTEXT trong script tối ưu.

Nguồn: https://dev.mysql.com/doc/refman/8.4/en/fulltext-natural-language.html

## 5. Bảng Archive và đánh đổi Read/Write

Câu hỏi phân tích: Nếu gần như không ghi, nhiều index có còn gây thảm họa không?

Kết luận: Chi phí duy trì lúc ghi giảm đáng kể; index phục vụ truy vấn có thể hợp lý. Tuy vậy, chúng vẫn chiếm disk, cạnh tranh cache và làm tăng thời gian backup/tạo lại. Quyết định dựa trên truy vấn thực tế, selectivity, EXPLAIN và đo tài nguyên. Giữ user_id/created_at theo workload đã nêu; loại đúng content/post_type/is_visible. Không xóa toàn bộ index và không xóa PRIMARY KEY.

Nguồn: https://dev.mysql.com/doc/refman/8.0/en/optimization-indexes.html

## Kiểm chứng và giới hạn

Đã đối chiếu thiết kế với tài liệu MySQL chính thức và kiểm tra script chỉ có ba lệnh DROP INDEX mục tiêu. Môi trường hỗ trợ không có MySQL Server nên chưa chạy DDL hay đo MB/thời gian INSERT. Script sinh log trước/sau từ dữ liệu thật khi chạy; các ô chưa đo trong báo cáo phải được cập nhật bằng kết quả đó.
