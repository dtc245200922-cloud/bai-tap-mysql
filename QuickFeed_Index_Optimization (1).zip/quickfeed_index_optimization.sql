-- QUICKFEED: TOI UU INDEX CO CHON LOC
-- MySQL 8.0+, InnoDB. Chay tren ban sao du lieu thuc hanh.
-- Dieu kien: da chay Legacy Script, bang Posts co du 5 secondary index.
-- Script khong xoa bang, khong xoa PRIMARY KEY, khong thay doi bai viet.
-- Chay toan bo trong cung mot ket noi. Luu Result Grid truoc khi dong ket noi.
-- Chi chay phan DROP mot lan; lan tiep theo index da bi xoa se bao loi.

USE quickfeed_db;

-- Tranh doc thong ke cu tu cache information_schema cua MySQL 8.0.
SET @old_stats_expiry = @@SESSION.information_schema_stats_expiry;
SET SESSION information_schema_stats_expiry = 0;

-- 1. Kiem tra cau truc, so lieu va ke hoach thuc thi truoc toi uu.
SHOW CREATE TABLE Posts;
ANALYZE TABLE Posts;
SHOW INDEX FROM Posts;
SHOW TABLE STATUS LIKE 'Posts';

SELECT TABLE_NAME,
       ROUND(DATA_LENGTH / 1048576, 4) AS data_mb,
       ROUND(INDEX_LENGTH / 1048576, 4) AS index_mb,
       ROUND((DATA_LENGTH + INDEX_LENGTH) / 1048576, 4) AS total_mb,
       ROUND(DATA_FREE / 1048576, 4) AS free_in_tablespace_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

SELECT DATA_LENGTH, INDEX_LENGTH, DATA_FREE
INTO @data_before, @index_before, @free_before
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

SELECT COUNT(DISTINCT INDEX_NAME) INTO @secondary_before
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts'
  AND INDEX_NAME <> 'PRIMARY';

-- Cardinality thuc te; COUNT(DISTINCT) khong tinh NULL.
-- Truy van nay quet du lieu, nen chay tren ban sao khi bang rat lon.
SELECT COUNT(*) AS row_count,
       COUNT(DISTINCT user_id) AS distinct_users,
       COUNT(DISTINCT post_type) AS distinct_types,
       COUNT(DISTINCT is_visible) AS distinct_visibility,
       ROUND(100.0 * SUM(is_visible = 1) / NULLIF(COUNT(*), 0), 2) AS visible_percent
FROM Posts;

EXPLAIN SELECT * FROM Posts WHERE is_visible = 1;
EXPLAIN SELECT * FROM Posts WHERE user_id = 1;
EXPLAIN SELECT * FROM Posts ORDER BY created_at DESC LIMIT 20;

-- 2. Loai bo dung BA index theo Decision Matrix.
-- idx_content: prefix 255 ky tu, khong phu hop tim tu khoa bat ky trong noi dung.
ALTER TABLE Posts DROP INDEX idx_content;
-- idx_post_type: it gia tri, loi ich thap voi workload cua de bai.
ALTER TABLE Posts DROP INDEX idx_post_type;
-- idx_is_visible: truy van lay 99% dong co do chon loc thap.
ALTER TABLE Posts DROP INDEX idx_is_visible;
-- GIU PRIMARY, idx_user_id va idx_created_at.

-- 3. Do lai sau toi uu; ANALYZE cap nhat thong ke, khong thu gon tep .ibd.
ANALYZE TABLE Posts;
SHOW INDEX FROM Posts;
SHOW TABLE STATUS LIKE 'Posts';

SELECT DATA_LENGTH, INDEX_LENGTH, DATA_FREE
INTO @data_after, @index_after, @free_after
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts';

SELECT COUNT(DISTINCT INDEX_NAME) INTO @secondary_after
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts'
  AND INDEX_NAME <> 'PRIMARY';

-- Bang log so sanh tu so lieu cua he thong dang chay.
SELECT 'Truoc' AS phase,
       ROUND(@data_before / 1048576, 4) AS data_mb,
       ROUND(@index_before / 1048576, 4) AS index_mb,
       ROUND((@data_before + @index_before) / 1048576, 4) AS total_mb,
       ROUND(@free_before / 1048576, 4) AS free_in_tablespace_mb,
       @secondary_before AS secondary_indexes
UNION ALL
SELECT 'Sau', ROUND(@data_after / 1048576, 4),
       ROUND(@index_after / 1048576, 4),
       ROUND((@data_after + @index_after) / 1048576, 4),
       ROUND(@free_after / 1048576, 4), @secondary_after;

SELECT ROUND((@index_before - @index_after) / 1048576, 4) AS index_reduction_mb,
       ROUND(100.0 * (@index_before - @index_after)
             / NULLIF(@index_before, 0), 2) AS index_reduction_percent,
       @secondary_before - @secondary_after AS fewer_secondary_trees_per_insert;

-- Kiem tra giu lai dung index va khong con ba index can loai bo.
SELECT INDEX_NAME, COLUMN_NAME, INDEX_TYPE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'quickfeed_db' AND TABLE_NAME = 'Posts'
ORDER BY INDEX_NAME, SEQ_IN_INDEX;

EXPLAIN SELECT * FROM Posts WHERE user_id = 1;
EXPLAIN SELECT * FROM Posts ORDER BY created_at DESC LIMIT 20;

-- Result Grid nay la Markdown co so lieu that de dan vao bao cao.
SELECT CONCAT(
    '| Trước | ', ROUND(@data_before / 1048576, 4), ' | ',
    ROUND(@index_before / 1048576, 4), ' | ', @secondary_before, ' |', CHAR(10),
    '| Sau | ', ROUND(@data_after / 1048576, 4), ' | ',
    ROUND(@index_after / 1048576, 4), ' | ', @secondary_after, ' |', CHAR(10),
    CHAR(10), 'Index giảm: ', ROUND((@index_before - @index_after) / 1048576, 4),
    ' MB (', COALESCE(CAST(ROUND(100.0 * (@index_before - @index_after)
      / NULLIF(@index_before, 0), 2) AS CHAR), 'không xác định'), '%).'
) AS markdown_storage_log;

SET SESSION information_schema_stats_expiry = @old_stats_expiry;

-- 4. Tuy chon van hanh: KHONG tu dong chay khi dia dang day.
-- DROP index giai phong trang cho tablespace tai su dung, nhung tep .ibd
-- khong nhat thiet nho lai. Muon tra disk cho OS voi file-per-table,
-- can du dung luong tam, sao luu va lich bao tri truoc khi rebuild:
-- OPTIMIZE TABLE Posts;
-- Do lai stats va kich thuoc tep/disk OS sau rebuild neu thuc hien.

-- 5. Goi y tim kiem van ban: KHONG tao them index trong bai toi uu nay.
-- Chi tao FULLTEXT neu co nhu cau tim kiem theo tu, sau khi do tai/dung luong.
-- ALTER TABLE Posts ADD FULLTEXT INDEX ft_content (content);
-- SELECT post_id, content FROM Posts
-- WHERE MATCH(content) AGAINST('hoc tap' IN NATURAL LANGUAGE MODE);
-- FULLTEXT van ton dung luong; khong bao dam nho hon prefix B-Tree.
