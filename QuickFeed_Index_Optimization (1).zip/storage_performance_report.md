# Báo cáo tối ưu Index — QuickFeed

Bảng Posts có năm secondary index ngoài PRIMARY KEY. Mỗi INSERT phải bổ sung bản ghi vào clustered index và năm cây chỉ mục phụ; đây là sáu cấu trúc logic cần duy trì, không phải sáu lần ghi đĩa cố định. Chi phí sửa trang, chia trang và ghi log có thể tăng I/O, gây áp lực buffer pool và kéo dài thời gian ghi.

Loại bỏ idx_content, idx_post_type, idx_is_visible; giữ idx_user_id và idx_created_at. Index content(255) lưu tiền tố dài nhưng không hỗ trợ hiệu quả tìm từ khóa ở vị trí bất kỳ. Hai index còn lại có cardinality thấp; với 99% bài viết hiển thị, quét bảng có thể rẻ hơn dò index rồi lấy gần toàn bộ dữ liệu.

Sau tối ưu, secondary index giảm từ 5 xuống 2: mỗi INSERT giảm ba cây cần duy trì. Đổi lại, truy vấn theo loại/trạng thái có thể chậm hơn; cần đối chiếu EXPLAIN và workload. Không suy ra tốc độ ghi tăng ba lần. Bảng Archive ít ghi chịu tác động nhỏ hơn, nhưng index dư vẫn tốn RAM và disk.

DATA_LENGTH và INDEX_LENGTH là thống kê xấp xỉ. DROP INDEX không bảo đảm tệp .ibd thu nhỏ; dung lượng có thể được tái sử dụng trong tablespace.

## Ma trận quyết định

| Index | Quyết định | Lý do theo workload đề bài |
|---|---|---|
| idx_user_id | Giữ | Lọc bài viết của một người dùng |
| idx_content | Xóa | Tiền tố dài, không phục vụ tìm từ khóa bên trong văn bản |
| idx_post_type | Xóa | Ba giá trị, lợi ích thấp trong các truy vấn đã nêu |
| idx_is_visible | Xóa | Hai giá trị; lọc 99% dòng ít chọn lọc |
| idx_created_at | Giữ | Hỗ trợ thứ tự thời gian của newsfeed |
| PRIMARY | Giữ | Khóa chính và tổ chức dữ liệu InnoDB |

## Log dung lượng

Đo trên MySQL 8.0.46, InnoDB, với 10.000 bài viết giả lập. Số liệu lấy từ Result Grid `markdown_storage_log` sau khi chạy script tối ưu ngày 05/10/2026. Một MB trong script bằng 1.048.576 byte.

| Giai đoạn | Data MB | Index MB | Secondary index |
|---|---:|---:|---:|
| Trước | 7.5156 | 7.7500 | 5 |
| Sau | 7.5156 | 1.7188 | 2 |

INDEX_LENGTH giảm **6.0313 MB (77.82%)** theo kết quả SQL tính từ số byte trước khi làm tròn. DATA_LENGTH giữ nguyên 7.5156 MB. Đây là mức giảm dung lượng chỉ mục được thống kê, chưa phải phép đo dung lượng ổ đĩa trả về hệ điều hành. Kết quả kiểm tra sau tối ưu còn ba index: PRIMARY, idx_user_id và idx_created_at.

Không dùng mức “5–10 giây” của tình huống làm kết quả benchmark. Muốn xác nhận tốc độ ghi, đo cùng tập INSERT trên hai bản sao trước/sau với cùng cấu hình, số dòng và điều kiện cache.

## Tham khảo

- https://dev.mysql.com/doc/mysql-infoschema-excerpt/8.0/en/information-schema-tables-table.html
- https://dev.mysql.com/doc/refman/8.0/en/innodb-index-types.html
